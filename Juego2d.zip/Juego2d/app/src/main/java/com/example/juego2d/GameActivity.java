package com.example.juego2d;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class GameActivity extends AppCompatActivity {

    private ImageView adventurerSprite;
    private ImageView batEnemySprite;
    private ImageView warriorEnemySprite;
    private Handler handler = new Handler();

    private Bitmap spriteSheet;
    private Bitmap batIdleSheet, batAttackSheet;
    private Bitmap warriorIdleSheet, warriorRunSheet, warriorAttackSheet;

    private int frameIndex = 0;
    private int frameWidth;
    private int frameHeight;
    private int frameCount;

    private int enemyFrameIndex = 0;
    private int enemyFrameWidth;
    private int enemyFrameHeight;
    private int enemyFrameCount;

    private static final int FRAME_DURATION = 100;
    private static final int MOVE_DISTANCE = 10;
    private static final int JUMP_HEIGHT = 200;
    private static final int GRAVITY = 10;

    private boolean isJumping = false;
    private boolean isMovingRight = false;
    private boolean isMovingLeft = false;
    private boolean isAttacking = false;
    private float originalY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Referencias
        adventurerSprite = findViewById(R.id.adventurer_sprite);
        batEnemySprite = findViewById(R.id.bat_enemy_sprite);
        warriorEnemySprite = findViewById(R.id.warrior_enemy_sprite);
        originalY = adventurerSprite.getY();

        // Botones de control
        Button btnRight = findViewById(R.id.btn_right);
        Button btnLeft = findViewById(R.id.btn_left);
        Button btnJump = findViewById(R.id.btn_jump);
        Button attackButton = findViewById(R.id.attackButton); // Botón de ataque

        // Cargar animación inicial
        loadSpriteSheet(R.drawable.adventurer_idle);
        startAnimation();
        createEnemies();

        // Movimiento continuo derecha
        btnRight.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                moveRight();
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                isMovingRight = false;
                setIdleAnimation();
            }
            return true;
        });

        // Movimiento continuo izquierda
        btnLeft.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                moveLeft();
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                isMovingLeft = false;
                setIdleAnimation();
            }
            return true;
        });

        // Saltar
        btnJump.setOnClickListener(v -> jump());

        // Ataque
        attackButton.setOnClickListener(v -> attack());
    }

    // ----------------------------- ANIMACIONES -----------------------------

    private void loadSpriteSheet(int spriteRes) {
        spriteSheet = BitmapFactory.decodeResource(getResources(), spriteRes);
        int sheetWidth = spriteSheet.getWidth();
        frameHeight = spriteSheet.getHeight();
        frameCount = sheetWidth / frameHeight;
        frameWidth = sheetWidth / frameCount;
    }

    private void startAnimation() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateFrame();
                handler.postDelayed(this, FRAME_DURATION);
            }
        }, FRAME_DURATION);
    }

    private void updateFrame() {
        Bitmap currentFrame = Bitmap.createBitmap(spriteSheet, frameIndex * frameWidth, 0, frameWidth, frameHeight);
        adventurerSprite.setImageBitmap(currentFrame);
        frameIndex = (frameIndex + 1) % frameCount;
    }

    // ----------------------------- MOVIMIENTO -----------------------------

    private void moveCharacter() {
        new Thread(() -> {
            while (isMovingRight || isMovingLeft) {
                runOnUiThread(() -> {
                    if (isMovingRight) {
                        adventurerSprite.setX(adventurerSprite.getX() + MOVE_DISTANCE);
                    }
                    if (isMovingLeft) {
                        adventurerSprite.setX(adventurerSprite.getX() - MOVE_DISTANCE);
                    }
                });
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void moveRight() {
        adventurerSprite.setScaleX(1f);
        isMovingRight = true;
        setRunningAnimation();
        moveCharacter();
    }

    private void moveLeft() {
        adventurerSprite.setScaleX(-1f);
        isMovingLeft = true;
        setRunningAnimation();
        moveCharacter();
    }

    private void jump() {
        if (!isJumping) {
            isJumping = true;
            setJumpingAnimation();

            new Thread(() -> {
                for (int i = 0; i < JUMP_HEIGHT / GRAVITY; i++) {
                    runOnUiThread(() -> adventurerSprite.setY(adventurerSprite.getY() - GRAVITY));
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                for (int i = 0; i < JUMP_HEIGHT / GRAVITY; i++) {
                    runOnUiThread(() -> adventurerSprite.setY(adventurerSprite.getY() + GRAVITY));
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                runOnUiThread(() -> {
                    if (isMovingRight || isMovingLeft) {
                        setRunningAnimation();
                    } else {
                        setIdleAnimation();
                    }
                    isJumping = false;
                });
            }).start();
        }
    }

    // Cambiar a animación idle
    private void setIdleAnimation() {
        loadSpriteSheet(R.drawable.adventurer_idle);
        frameIndex = 0;
    }

    // Cambiar a animación running
    private void setRunningAnimation() {
        loadSpriteSheet(R.drawable.adventurer_running);
        frameIndex = 0;
    }

    // Cambiar a animación jumping
    private void setJumpingAnimation() {
        loadSpriteSheet(R.drawable.adventurer_flying);
        frameIndex = 0;
    }

    // ----------------------------- ATAQUE -----------------------------

    private void attack() {
        if (!isAttacking) {
            isAttacking = true;
            adventurerSprite.setColorFilter(Color.RED);
            checkCollision();
            handler.postDelayed(() -> {
                adventurerSprite.clearColorFilter();
                isAttacking = false;
            }, 500);
        }
    }

    private void checkCollision() {
        if ((batEnemySprite != null && batEnemySprite.getVisibility() == View.VISIBLE &&
                adventurerSprite.getX() + adventurerSprite.getWidth() > batEnemySprite.getX() &&
                adventurerSprite.getX() < batEnemySprite.getX() + batEnemySprite.getWidth())) {
            batEnemySprite.setVisibility(View.GONE);
        }

        if ((warriorEnemySprite != null && warriorEnemySprite.getVisibility() == View.VISIBLE &&
                adventurerSprite.getX() + adventurerSprite.getWidth() > warriorEnemySprite.getX() &&
                adventurerSprite.getX() < warriorEnemySprite.getX() + warriorEnemySprite.getWidth())) {
            warriorEnemySprite.setVisibility(View.GONE);
        }
    }

    // ----------------------------- ENEMIGOS -----------------------------

    private void createEnemies() {
        loadEnemySpriteSheets();
        startEnemyAnimation();
    }

    private void loadEnemySpriteSheets() {
        batIdleSheet = BitmapFactory.decodeResource(getResources(), R.drawable.bat_idle_moving);
        batAttackSheet = BitmapFactory.decodeResource(getResources(), R.drawable.bat_attack);
        warriorIdleSheet = BitmapFactory.decodeResource(getResources(), R.drawable.warrior_idle);
        warriorRunSheet = BitmapFactory.decodeResource(getResources(), R.drawable.warrior_run);
        warriorAttackSheet = BitmapFactory.decodeResource(getResources(), R.drawable.warrior_attack);
    }

    private void startEnemyAnimation() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateEnemyFrames();
                handler.postDelayed(this, FRAME_DURATION);
            }
        }, FRAME_DURATION);
    }

    private void updateEnemyFrames() {
        Bitmap currentBatFrame = Bitmap.createBitmap(batIdleSheet, enemyFrameIndex * 32, 0, 32, 32);
        batEnemySprite.setImageBitmap(currentBatFrame);

        Bitmap currentWarriorFrame = Bitmap.createBitmap(warriorIdleSheet, enemyFrameIndex * 32, 0, 32, 32);
        warriorEnemySprite.setImageBitmap(currentWarriorFrame);

        enemyFrameIndex = (enemyFrameIndex + 1) % 4;
    }
}
